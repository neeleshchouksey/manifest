                <!-- Info section Title-->
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h1>Services</h1>
                            <p class="lead">Bespoke mobile apps or web apps. eCommerce or chatbots. Product development or software design services. Dedicated hiring or a fixed quote. One-time or ongoing. We offer everything to cater to the unique needs of our clients.   </p>
                        </div>
                    </div>
                </div>            
                <!-- End Info section Title--> 
            </header>
            <!-- End Header Section-->
    
            <!-- End content info - White Section-->
            <section class="content_info">
                <!-- Info Resalt-->
                <div class="paddings">
                    <div class="container wow fadeInUp">
                        <div class="row">
                            <!-- Item Service-02-->
                            <div class="col-sm-6 col-md-4">
                                <div class="service-02">
                                    <div class="head-service-02">
                                        <img src="<?php echo base_url();?>/assets/images/icons/web-development.png">
                                        <h3>
                                            &nbsp;&nbsp;&nbsp;Web Development
                                        </h3>
                                    </div>
                                    <div class="caption-service-02">
                                        <p>We offer custom web development services, ranging from simple brochure websites to complex web applications. We have expertise in a variety of technologies, including HTML, CSS, JavaScript, PHP, Laravel, Codeigniter, Drupal, Wordpress, Symphony, Zend, Cake PHP.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- End Item Service-02-->

                            <!-- Item Service-02-->
                            <div class="col-sm-6 col-md-4">
                                <div class="service-02">
                                    <div class="head-service-02">
                                        <img src="<?php echo base_url();?>/assets/images/icons/app-development.png">
                                        <h3>
                                           &nbsp;&nbsp;&nbsp;Mobile App Development
                                        </h3>
                                    </div>
                                    <div class="caption-service-02">
                                        <p>We create native and cross-platform mobile apps for iOS and Android. Our developers have expertise in both front-end and back-end development, and we can help you bring your app idea to life.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- End Item Service-02-->

                             <!-- Item Service-02-->
                            <div class="col-sm-6 col-md-4">
                                <div class="service-02">
                                    <div class="head-service-02">
                                        <img src="<?php echo base_url();?>/assets/images/icons/web-design.png">
                                        <h3>
                                            &nbsp;&nbsp;&nbsp;Web Design
                                        </h3>
                                    </div>
                                    <div class="caption-service-02">
                                        <p>We use responsive design techniques to ensure that your website looks and functions perfectly on any device. In addition to UX/UI design, we also offer a range of graphics design services, including logo design, brand identity development, and marketing materials design.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- End Item Service-02-->
                        </div>
                    </div> 
                </div>
                <!-- End Info Resalt-->
            </section>   
            <!-- End content info - White Section-->    

            <!-- End content info - Dark Section-->
            <section class="content_info">
                <!-- Info Resalt-->
                <div class="info_dark paddings">
                    <div class="container wow fadeInUp">
                        <div class="row">
                            <!-- Item Service-02-->
                            <div class="col-sm-6 col-md-4">
                                <div class="service-02">
                                    <div class="head-service-02">
                                        <img src="<?php echo base_url();?>/assets/images/icons/web-maintenance.png">
                                        <h3>
                                            &nbsp;&nbsp;&nbsp;Website Maintenance
                                        </h3>
                                    </div>
                                    <div class="caption-service-02">
                                        <p>We offer ongoing maintenance and support to keep your website running smoothly. This includes security updates, bug fixes, and content updates.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- End Item Service-02-->

                             <!-- Item Service-02-->
                            <div class="col-sm-6 col-md-4">
                                <div class="service-02">
                                    <div class="head-service-02">
                                        <img src="<?php echo base_url();?>/assets/images/icons/digitalmarketing.png">
                                        <h3>
                                            &nbsp;&nbsp;&nbsp;Digital Marketing
                                        </h3>
                                    </div>
                                    <div class="caption-service-02">
                                        <p>Our team is skilled in social media marketing, and email marketing. We can help you create and execute a digital marketing strategy that drives traffic and generates leads for your business.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- End Item Service-02-->

                             <!-- Item Service-02-->
                            <div class="col-sm-6 col-md-4">
                                <div class="service-02">
                                    <div class="head-service-02">
                                        <img src="<?php echo base_url();?>/assets/images/icons/search-engine-optimization.png">
                                        <h3>
                                            &nbsp;&nbsp;&nbsp;SEO
                                        </h3>
                                    </div>
                                    <div class="caption-service-02">
                                        <p>Our SEO services are designed to help your website rank higher in search results, attract more qualified traffic, and ultimately drive more sales and leads. We use a combination of on-page optimization, content marketing, and link building to improve your website's visibility and credibility.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- End Item Service-02-->                   
                        </div>
                    </div>
                </div>
                <!-- End Info Resalt-->
            </section>   
            <!-- End content info - Dark Section--> 

            <!-- End content info - White Section-->
            <section class="content_info">
                <!-- Info Resalt-->
                <div class="paddings">
                    <div class="container">
                        <div class="row">
                           <div class="col-md-6 wow fadeInRight animated">
                            
                                <!-- Item Service-02-->
                                <div class="col-sm-6 col-md-12">
                                    <div class="service-02">
                                        <div class="head-service-02">
                                            <img src="<?php echo base_url();?>/assets/images/icons/industry-specific.png">
                                            <h3>
                                                &nbsp;&nbsp;&nbsp;Industry-specific web and app development
                                            </h3>
                                        </div>
                                        <div class="caption-service-02">
                                            <p>There are many sectors in which we have created web and app solutions to meet the needs of our clients. Some of them are:<br><br>

                                            Education & learning<br>
                                            Banking and Finance<br>
                                            B2B/B2C Portal<br>
                                            Retail & E-Commerce<br>
                                            Events & Ticketing<br>
                                            Enterprise & Business<br>
                                            Entertainment & Media<br>
                                            Transportation<br>
                                            Real Estate & Housing<br>
                                            Travel and Hospitality<br>
                                            Automotives<br>
                                            Healthcare<br>
                                            Construction<br>
                                            Sports and Gaming<br>


                                        </div>
                                    </div>
                                </div>
                                <!-- End Item Service-02-->
                                
                            </div>
                             <div class="col-md-6 wow fadeInLeft animated">
                                <!-- Slide -->  
                                <ul class="carousel-single" id="carousel-single">
                                    <li><img src="<?php echo base_url();?>/assets/images/gallery/service1.jpg" alt="" class="img-responsive"></li>
                                    <li><img src="<?php echo base_url();?>/assets/images/gallery/service2.jpg" alt="" class="img-responsive"></li>
                                    <li><img src="<?php echo base_url();?>/assets/images/gallery/service4.jpg" alt="" class="img-responsive"></li>             
                                </ul>
                                <!-- End Slide -->   
                            </div>
                        </div>
                    </div> 
                </div>
                <!-- End Info Resalt-->
            </section>   
            <!-- End content info - White Section--> 

            <!-- End content info - Video Section -->
            <section class="content_info">
                <!-- Vide Background -->
                <video class="bg_video" preload="auto" autoplay="autoplay" loop muted>                        
                  <source src="<?php echo base_url();?>/assets/images/video/video.mp4" type="video/mp4">
                </video>
                <!-- Vide Background -->

                <!-- Content Video
                <section class="opacy_bg_03 paddings borders">
                    <div class="container wow fadeInUp">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <h1>Section with video background</h1>
                                <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>
                            </div>

                            <div class="col-md-12 text-center padding-top-mini">
                                <a class="button" href="#">Start now</a>
                                <a class="btn" href="#">More info</a>
                            </div>
                        </div>
                    </div> 
                </section>  
                End Content Video--> 
            </section>   
            <!-- End content info - Video Section --> 

             <!-- End content info - info Section-->
            <section class="content_info">
                <!-- testimonials-->
                <section class="info_resalt border_top">  
                    <div class="container wow fadeInDown">
                        <div class="important-info">
                            <!-- <h1>Join The <span>Jekas</span> and Get Lots of Awesome Features</h1> -->
                            <h4><i>Our support doesn't end when the project is completed - we offer ongoing maintenance and updates. Try our services today!</i></h4>
                            <!-- <a href="#" class="btn button">Read More About</a>
                            <a href="#" class="btn button">Purchase Now!</a> -->
                        </div>
                    </div>
                </section>  
                <!-- End testimonials--> 
            </section>   
            <!-- End content info - info Section--> 

            