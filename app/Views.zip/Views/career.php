<script>
	$('#career a').css('background-color','#056ab2');
	$('#career a').css('color','#FFF');
</script>

<!-----top navigations section closed here...-------->
<section class="page-cover career-cover-img">
  <div class="container-fluid">
    <div class="container">
      <div class="page-heading">
        <h3>CAREER</h3>
        <h4>We open the door of "HOPE"</h4>
        <p> Our career offerings make the way for the job seekers. Our career plan is to give opportunity for many people to expand our human resource base </p>
      </div>
    </div>
  </div>
</section>
<!--/page cover & career section--> 

<!--/page cover & career section--> 

<!--/career  & current opportunity section-->
<?php include "current-opportunity.php"; ?>
<!--/opportunity & footer--->
