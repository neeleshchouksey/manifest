                <!-- Info section Title-->
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h1>About Us</h1>
                            <p class="lead"> Development Partner for Global Enterprises, SMEs, Digital Agencies, and Startups.</p>
                        </div>
                    </div>
                </div>            
                <!-- End Info section Title--> 
            </header>
            <!-- End Header Section-->

            <!-- End content info - White Section-->
            <section class="content_info">
                <!-- Info Resalt-->
                <div class="paddings">
                    <div class="container wow fadeInUp">
                        <div class="row">
                            <div class="col-md-4">
                                <h3>Our Company</h3>
                                <p>Welcome to Manifest Infotech, a leading web and app development company founded in 2012 specializing in creating innovative and intuitive digital solutions for businesses and organizations around the globe.  Whether you need a simple website, a complex app, or something in between, we have the skills and experience to make it happen.</p>
                            </div> 
                            <div class="col-md-4">
                                <h3>Work Culture</h3>
                                <p>At our office, we work with fun and also make our clients feel at ease of not just a working company but an agency with good vibes and activities. We organize various parties at the office as well as places outside to keep our workplace full of enthusiasm. We celebrate every achievement as well as keep our environment to encourage openness and free expression of ideas.</p>
                            </div> 
                            <div class="col-md-4">
                                <h3>Work Methodology</h3>
                                <p>At our company, we use Agile methodology to ensure that we are delivering the best possible products to our clients in a timely and efficient manner. In Agile development, teams work in short cycles, called sprints, to develop and deliver functionalities. This approach allows for flexibility and adaptation to changes, as well as regular communication and collaboration between team members.</p>
                            </div>                    
                        </div>
                    </div>
                </div>
                <!-- End Info Resalt-->
            </section>   
            <!-- End content info - White Section--> 

            <!-- End content info - Parallax Section 02 -->
            <section class="content_info">
                <!-- Parallax Background -->
                <div class="bg_parallax image_02_parallax"></div>
                <!-- Parallax Background -->

                <!-- Content Parallax-->
                <section class="opacy_bg_02 paddings">
                    <div class="container wow fadeInUp">
                        <!-- Resul-->
                        <div class="row results results-no-top">
                            <div class="col-md-3">
                                <img src="<?php echo base_url();?>/assets/images/icons/team.png">
                                <h2>55 </h2>
                                <h5>Team Size</h5>                                
                            </div>
                            <div class="col-md-3">
                                <img src="<?php echo base_url();?>/assets/images/icons/client-served.png">
                                <h2>120+ </h2>
                                <h5>Client Served</h5>
                            </div>
                            <div class="col-md-3">
                                 <img src="<?php echo base_url();?>/assets/images/icons/completed-projects.png">
                                <h2>195+ </h2>
                                <h5>Projects completed</h5>
                            </div>
                            <div class="col-md-3">                                    
                                <img src="<?php echo base_url();?>/assets/images/icons/years-of-experience.png">
                                <h2>10+ </h2>
                                <h5>Years of Experience</h5>
                            </div>
                        </div>   
                        <!-- End Resul-->   
                    </div> 
                </section>  
                <!-- End Content Parallax--> 
            </section>   
            <!-- End content info - Parallax Section 02 --> 

            <!-- Info title-->
            <div class="row-fluid info_title">
                <div class="vertical_line">
                    <div class="circle_bottom"></div>
                </div>
                <div class="info_vertical">
                    <h2>Meet some of our <span>team</span> members</h2>
                    <p>"We believe that teamwork and collaboration are key to delivering successful projects, and our team reflects that belief.”</p>
                </div>
                <div class="vertical_line"></div>

                <!-- <i class="fa fa-coffee left"></i> -->
            </div>
            <!-- End Info title-->

            <!-- Team-->
            <div class="info_resalt borders">                 
                <div class="container">
                    <div class="row">
                        <!-- Item Team-->
                        <div class="col-sm-6 col-md-3">
                            <div class="item-team">
                                <img src="<?php echo base_url();?>/assets/images/team/1.jpg" alt="">
                                <h4>Neelesh Chouksey
                                    <span>CEO</span>
                                </h4>
                            </div>
                        </div>
                        <!-- End Item Team-->

                        <!-- Item Team-->
                        <div class="col-sm-6 col-md-3">
                            <div class="item-team">
                                <img src="<?php echo base_url();?>/assets/images/team/2.jpg" alt="">
                                <h4>Prateek Yaduvanshi
                                    <span>Manager</span>
                                </h4>
                            </div>
                        </div>
                        <!-- End Item Team-->

                        <!-- Item Team-->
                        <div class="col-sm-6 col-md-3">
                            <div class="item-team">
                                <img src="<?php echo base_url();?>/assets/images/team/3.jpg" alt="">
                                <h4>Mayuri Shukla
                                    <span>BDE</span>
                                </h4>
                            </div>
                        </div>
                        <!-- End Item Team-->

                        <!-- Item Team-->
                        <div class="col-sm-6 col-md-3">
                            <div class="item-team">
                                <img src="<?php echo base_url();?>/assets/images/team/4.jpg" alt="">
                                <h4>Shivani Chouksey
                                    <span>HR</span>
                                </h4>
                            </div>
                        </div>
                        <!-- End Item Team-->
                    </div>
                </div>           
            </div>
            <!-- End Team-->

             <!-- End content info - White Section-->
            <section class="content_info">
                <!-- Info Resalt-->
                <div class="paddings">
                    <div class="container wow fadeInUp">
                        <div class="row">
                            <div class="col-md-6">
                                <h2>Who We Are</h2>
                                <p>Manifest Infotech is one of the leading Web, Mobile and AI Software Development and UX/UI Design companies in Europe, with offices in India and the Canada.</p>
                                <p>We helped design, build, launch, and scale 300+ web & mobile applications in the last 12 years. Following an Agile approach, we are committed to creating innovative digital products from scratch or assisting your team remotely.</p>
                            </div>  

                            <!-- skills-->
                            <div class="col-md-6">
                                <div class="skills-wrapper wow animated fadeInRight">
                                    <h6 class="heading-progress">Web Design <span class="pull-right">88%</span></h6>
                                    <div class="progress">
                                        <div class="progress-bar" style="width: 88%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="88" role="progressbar">
                                        </div>
                                    </div>
                                    <h6 class="heading-progress">Web Development <span class="pull-right">78%</span></h6>
                                    <div class="progress">
                                        <div class="progress-bar" style="width: 78%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="78" role="progressbar">
                                        </div>
                                    </div>
                                    <h6 class="heading-progress">Marketing <span class="pull-right">82%</span></h6>
                                    <div class="progress">
                                        <div class="progress-bar" style="width: 82%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="82" role="progressbar">
                                        </div>
                                    </div>  
                                    <h6 class="heading-progress">Front End <span class="pull-right">90%</span></h6>
                                    <div class="progress">
                                        <div class="progress-bar" style="width: 90%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="90" role="progressbar">
                                        </div>
                                    </div>                    
                                </div>
                                <!--End skills-->
                            </div>                 
                        </div>
                    </div>
                </div>
                <!-- End Info Resalt-->
            </section>   
            <!-- End content info - White Section--> 

            <!-- End content info - Video Section -->
            <section class="content_info">
                <!-- Vide Background -->
                <video class="bg_video" preload="auto" autoplay="autoplay" loop muted>                        
                  <source src="<?php echo base_url();?>/assets/video/about.mp4" type="video/mp4">
                </video>
                <!-- Vide Background -->

                <!-- Content Video
                <section class="opacy_bg_01 paddings borders">
                    <div class="container wow fadeInUp">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <h1>Section with video background</h1>
                                <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>
                            </div>

                            <div class="col-md-12 text-center padding-top-mini">
                                <a class="button" href="#">Start now</a>
                                <a class="btn" href="#">More info</a>
                            </div>
                        </div>
                    </div> 
                </section>  
                End Content Video--> 
            </section>   
            <!-- End content info - Video Section --> 
                
            <!-- Info title-->
            <div class="row-fluid info_title">
                <div class="vertical_line">
                    <div class="circle_bottom"></div>
                </div>
                <div class="info_vertical" id="scale-it">
                    <h2>Technology Stack</h2>
                    <p>“Our team is proficient in a wide range of programming languages and frameworks. This allows us to build scalable, reliable, and high-performing web and mobile applications for our clients.”</p>
                </div>
                <div class="vertical_line"></div>

                <!-- <i class="fa fa-tablet right"></i> -->
            </div>
            <!-- End Info title-->

            <!-- End content info - Grey Section-->
            <section class="content_info">
                <!-- Info Resalt-->
                <div class="info_resalt">
                    <div class="container wow fadeInUp">
                        <div class="row">
                            <div class="col-md-12">
                               <!-- Sponsors Zone-->     
                                <ul class="owl-carousel carousel-sponsors tooltip-hover" id="carousel-sponsors">
                                    <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/php.jpg" alt="Image"></a>
                                    </li>
                                    <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/laravel.jpg" alt="Image"></a>
                                    </li>
                                     <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/code-igniter.jpg" alt="Image"></a>
                                    </li>
                                    <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/node-js.jpg" alt="Image"></a>
                                    </li>
                                    <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/react-js.jpg" alt="Image"></a>
                                    </li>
                                    <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/angular-js.jpg" alt="Image"></a>
                                    </li>
                                    <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/wordpress.jpg" alt="Image"></a>
                                    </li>
                                     <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/html.jpg" alt="Image"></a>
                                    </li>
                                    <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/javascript.jpg" alt="Image"></a>
                                    </li>
                                    <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/css.jpg" alt="Image"></a>
                                    </li>
                                    <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/my-sql.jpg" alt="Image"></a>
                                    </li>
                                    <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/mongo-db.jpg" alt="Image"></a>
                                    </li>
                                    <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/github.jpg" alt="Image"></a>
                                    </li>  
                                    <li data-toggle="tooltip" title data-original-title="Name Sponsor">
                                        <a href="#"  class="tooltip_hover" title="Name Sponsor"><img src="<?php echo base_url();?>/assets/images/technology/aws.jpg" alt="Image"></a>
                                    </li>                                     
                                </ul> 
                                <!-- End Sponsors Zone-->    
                            </div>                    
                        </div>
                    </div>
                </div>
                <!-- End Info Resalt-->
            </section>   
            <!-- End content info - Grey Section-->