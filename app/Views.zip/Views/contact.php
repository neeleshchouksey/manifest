                <!-- Info section Title-->
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h1>Contact Us</h1>
                            <p class="lead">We're here to help with all your Web Development needs. Contact us for a free consultation and quote. Drop us a line and let's start building your dream website.</p>
                        </div>
                    </div>
                </div>            
                <!-- End Info section Title--> 
            </header>
            <!-- End Header Section-->

            <!-- End content info - Grey Section-->
            <section class="content_info">
                <!-- Info Resalt-->
                <div class="info_resalt border-top">
                    <div class="container wow fadeInUp">
                        <div class="row">
                           <div class="col-md-6">
                                <h3>Contact Form</h3>
                                <form id="form" action="php/send_mail.php">
                                    <input type="text" placeholder="Name" name="Name" required>
                                    <input type="email" placeholder="Email"  name="Email" required>
                                    <input type="number" placeholder="Phone"  name="Phone" required>
                                    <textarea placeholder="Your Message" name="message" required></textarea>
                                    <input type="submit" name="Submit" value="Send Message" class="button">
                                </form> 
                                <div id="result"></div>  
                            </div>

                            <div class="col-md-6">
                                <h3>Get in touch</h3>
                                For all inquiries, please fill the form or send us an email at <a href="mailto:info@manifestinfotech.com">info@manifestinfotech.com</a>. We look forward to connect with you.
                                <br><br>
                                Tel: +91 731 3582993, +91 7771983222<br>
                                <br><br>
                                
                                <!-- Map area-->
                                <section class="map_area">
                                    <iframe  src="https://maps.google.es/maps?f=q&amp;source=s_q&amp;hl=es&amp;geocode=&amp;q=new+york&amp;aq=&amp;sll=40.396764,-3.713379&amp;sspn=9.61761,19.753418&amp;ie=UTF8&amp;hq=&amp;hnear=Nueva+York,+Estados+Unidos&amp;ll=40.614353,-74.005973&amp;spn=0.598524,1.234589&amp;t=m&amp;z=10&amp;output=embed">
                                    </iframe>
                                </section>
                                <!-- End Map area-->
                            </div>                 
                        </div>
                    </div>
                </div>
                <!-- End Info Resalt-->
            </section>   
            <!-- End content info - Grey Section--> 

            <!-- End content info - White Section-->
            <section class="content_info">
                <!-- Info Resalt-->
                <div class="paddings">
                    <div class="container wow fadeInUp">
                        <div class="row">
                            <!-- Item Location -->
                            <div class="col-md-6">
                               <div class="row">
                                 <div class="col-md-6">
                                        <img src="<?php echo base_url();?>/assets/images/office/1.jpg" alt="" class="img-responsive">
                                    </div>
                                    <div class="col-md-6">
                                        <h4>Indore Office</h4>
                                        <p>B-319, Opposite Of Apollo DB City,
                                        <br>Near Iglookids School,
                                        <br>Tulsi Nagar, Indore, M.P., India<br>
                                    </div>
                               </div>
                            </div> 
                            <!-- Item Location--> 

                            <!-- Item Location--> 
                            <div class="col-md-6">
                                 <div class="row">
                                    <div class="col-md-6">
                                        <img src="<?php echo base_url();?>/assets/images/office/2.jpg" alt="" class="img-responsive">
                                    </div>
                                    <div class="col-md-6">
                                        <h4>Delhi Office</h4>
                                        <p>Corp. Office – Plot No 429,
                                        <br>Metro Pillor No-795 Dwarka
                                        <br>Mor Metro Station,
                                        <br>New Delhi-110078, India<br>
                                    </div>
                                    
                               </div>
                            </div> 

                            <!-- End Item Location--> 
                        </div>
                    </div>
                </div>
                <!-- End Info Resalt-->
            </section>   
            <!-- End content info - White Section-->