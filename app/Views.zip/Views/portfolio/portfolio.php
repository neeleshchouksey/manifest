                <!-- Info section Title-->
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h1>Our Work</h1>
                            <p class="lead">Showcasing our expertise and experience in delivering exceptional results.</p>
                        </div>
                    </div>
                </div>            
                <!-- End Info section Title--> 
            </header>
            <!-- End Header Section-->

            <!-- Info title-->
            <div class="row info_title wow animated fadeInUp">
                <div class="vertical_line">
                    <div class="circle_bottom"></div>
                </div>
                <div class="info_vertical">
                    <h2>Our <span>projects</span> speak well of us.</h2>
                    <p>Proudly displaying a record of delivering successful IT projects for a diverse range of clients. Our portfolio showcases our technical prowess and ability to turn complex solutions into user-friendly, efficient systems.</p>                    
                </div>
                <div class="vertical_line"></div>

                <!-- <i class="fa fa-html5 right"></i>
                <i class="fa fa-css3 left"></i> -->
            </div>
            <!-- End Info title-->

            <!-- End content info - Grey Section-->
            <section class="content_info">
                <!-- Info Resalt-->
                <div class="info_resalt borders">
                   <div class="container">

                        <!-- Nav Filters -->
                        <div class="portfolioFilter">
                            <a href="#" data-filter="*" class="current">Show All</a>
                            <a href="#design" data-filter=".design">Desing</a>
                            <a href="#dev" data-filter=".dev">Development</a>
                            <a href="#seo" data-filter=".seo">Seo</a>
                            <!-- <a href="#retina" data-filter=".retina">Retina Desing</a> -->
                        </div>
                        <!-- End Nav Filters -->
                        
                        
                        <div class="row portfolioContainer">
                            <!-- Item Work-->
                            <?php
                            $count = 0;
                            //echo "<pre>";//print_r($all_project_data);exit;
                            foreach ($all_project_data as $project) {
                                //print_r($project['category_id']);continue;
                                $count++;
                                $dashedProjectName = strtolower(str_replace(' ', '-', $project['project_name']));
                                $thumbPath = "assets/images/portfolio/" . $dashedProjectName;
                                $gId = $project['category_id'];
                                ?>
                                <!-- Items Works filters-->
                                <div class="col-sm-6 col-md-6 <?php if ($gId == 1) {
                                    echo 'design';
                                } elseif ($gId == 2) {
                                    echo 'dev';
                                } else {
                                    echo 'seo';
                                } ?>" >
                                    <div class="item-work">
                                        <div class="hover">
                                            <img src="<?php echo base_url().'/'.$thumbPath . '/' . $project['thumb']; ?>" alt="<?php echo strtolower($project['project_name']); ?>"/>                               
                                            <a href="<?php echo base_url().'/'.$thumbPath . '/' . $project['thumb']; ?>" class="ligbox-image" title="<?php echo strtoupper($project['project_name']); ?>"><div class="overlay"></div></a>
                                        </div>                                    
                                        <div class="info">
                                            <a href="<?php echo site_url('portfolio/project/' . $dashedProjectName); ?>"><?php echo strtoupper($project['project_name']); ?></a>
                                            <i class="fa fa-tablet"></i>
                                            <i class="fa fa-desktop"></i> 
                                        </div>
                                    </div>
                                </div>
                            <?php
                            }
                            ?>
                            <!-- End Item Work-->
                            
                        </div>    
                        <!-- End Items Works filters-->
                    </div>   
                </div>
                <!-- End Info Resalt-->
            </section>   
            <!-- End content info - Grey Section--> 

            