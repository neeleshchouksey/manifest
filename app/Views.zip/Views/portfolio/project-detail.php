
                <!-- Info section Title-->
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h1>Our Work</h1>
                            <p class="lead">Pellentesque habitant morbi tristique senectus et netus et malesuada fames.</p>
                        </div>
                    </div>
                </div>            
                <!-- End Info section Title--> 
            </header>
            <!-- End Header Section-->

            <!-- Info title-->
            <div class="row info_title wow animated fadeInUp">
                <div class="vertical_line">
                    <div class="circle_bottom"></div>
                </div>
                <div class="info_vertical">
                    <h2>Characteristics and <span>description</span> of the work.</h2>
                    <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.</p>                    
                </div>
                <div class="vertical_line"></div>

                <i class="fa fa-html5 right"></i>
            </div>
            <!-- End Info title-->

            <!-- End content info - Grey Section - works single-->
            <section class="content_info">
                <!-- Info Resalt-->
                <div class="info_resalt borders">
                    <div class="container">
                        <div class="row">
                           <!-- Description Work-->
                           <div class="col-md-4">      
                           
                                <h3 class="titles-span"></span><?php echo $project_data['project_heading1'];?></h3>                      
                                                            
                                <p>There are many variations passages available alteraised words which look even slightly believable.</p>
                                <ul class="list">
                                    <li><i class="fa fa-check"></i> Web Marketing</li>
                                    <li><i class="fa fa-check"></i> Responsive Desing</li>
                                    <li><i class="fa fa-check"></i> Reta Display</li>
                                    <li><i class="fa fa-check"></i> HTML5</li>
                                    <li><i class="fa fa-check"></i> Css3</li>                       
                                </ul>
                                <div class="technologies">
                                    <i class="fa fa-tablet"></i>
                                    <i class="fa fa-desktop"></i>
                                    <i class="fa fa-android"></i>
                                    <i class="fa fa-windows"></i>
                                </div>
                                <a href="http://themeforest.net/?ref=iwthemes" target="blank" class="button">Launch Project</a>
                            </div>
                             <!-- End Description Work-->
                            
                            <div class="col-md-8">                           
                                <!-- Slide -->  
                                <ul class="carousel-single" id="carousel-single">
                                     <?php $imagePath="assets/images/portfolio/".strtolower(str_replace(' ','-',$project_data['project_name']));?>
                                    <li><img src="<?php echo base_url().'/'.$imagePath.'/'.$project_data['image1'];?>" alt="" class="img-responsive"></li>
                                    <li><img src="<?php echo base_url().'/'.$imagePath.'/'.$project_data['image2'];?>" alt="" class="img-responsive"></li>
                                    <li><img src="<?php echo base_url().'/'.$imagePath.'/'.$project_data['image3'];?>" alt="" class="img-responsive"></li>             
                                </ul>
                                <!-- End Slide -->                            
                            </div>                        
                        </div>
                    </div>
                </div>
                <!-- End Info Resalt-->
            </section>   
            <!-- End content info - Grey Section - Works single--> 
            
            <!-- Info title-->
            <div class="row info_title wow fadeInUp">
                <div class="vertical_line">
                    <div class="circle_bottom"></div>
                </div>
                <div class="info_vertical animated">
                    <h1>Recent <span>Works</span> with Jekas.</h1>
                    <p class="">The fastest way to grow your business with the leader in Technology.</p>
                </div>
                <div class="vertical_line"></div>

                <i class="fa fa-css3 left"></i>
            </div>
            <!-- End Info title-->

            <!-- End content info - Portfolio Carousel Section-->
            <section class="content_info">
                <!-- Info Resalt-->
                <div class="info_resalt border-top">
                    <div class="container wow fadeInUp">
                        <div class="row">
                            <div class="col-md-12">
                                <!-- Carousel Gallery-->        
                                <ul class="owl-carousel carousel-portfolio" id="carousel-portfolio">
                                    <li>
                                        <div class="hover">
                                            <img src="<?php echo base_url();?>/assets/img/gallery/1.jpg" alt=""/>                               
                                            <a href="<?php echo base_url();?>/assets/img/gallery/1.jpg" class="ligbox-image" title="Image"><div class="overlay"></div></a>
                                        </div>                                   
                                        <div class="info">
                                            Responsive Design
                                            <i class="fa fa-tablet"></i>
                                            <i class="fa fa-desktop"></i> 
                                        </div>                                   
                                    </li>   
                                                
                                    <li>
                                        <div class="hover">
                                            <img src="<?php echo base_url();?>/assets/img/gallery/2.jpg" alt=""/>                               
                                            <a href="<?php echo base_url();?>/assets/img/gallery/2.jpg" class="ligbox-image" title="Image"><div class="overlay"></div></a>
                                        </div>                                   
                                        <div class="info">
                                            Vinilo - HTML Template
                                            <i class="fa fa-tablet"></i>
                                            <i class="fa fa-desktop"></i> 
                                        </div>                                   
                                    </li>
                                    
                                    <li>
                                        <div class="hover">
                                            <img src="<?php echo base_url();?>/assets/img/gallery/3.jpg" alt=""/>                               
                                            <a href="<?php echo base_url();?>/assets/img/gallery/3.jpg" class="ligbox-image" title="Image"><div class="overlay"></div></a>
                                        </div>                                   
                                        <div class="info">
                                            Mega Host - Responsive template
                                            <i class="fa fa-tablet"></i>
                                            <i class="fa fa-desktop"></i> 
                                        </div>                                   
                                    </li>  
                                      
                                    <li>
                                        <div class="hover">
                                            <img src="<?php echo base_url();?>/assets/img/gallery/4.jpg" alt=""/>                               
                                            <a href="<?php echo base_url();?>/assets/img/gallery/4.jpg" class="ligbox-image" title="Image"><div class="overlay"></div></a>
                                        </div>                                   
                                        <div class="info">
                                            My Cv - Responsive Resume / CV
                                            <i class="fa fa-tablet"></i>
                                            <i class="fa fa-desktop"></i> 
                                        </div>                                   
                                    </li>
                                          
                                    <li>
                                        <div class="hover">
                                            <img src="<?php echo base_url();?>/assets/img/gallery/5.jpg" alt=""/>                               
                                            <a href="<?php echo base_url();?>/assets/img/gallery/5.jpg" class="ligbox-image" title="Image"><div class="overlay"></div></a>
                                        </div>                                   
                                        <div class="info">
                                            Political - Landing Page
                                            <i class="fa fa-tablet"></i>
                                            <i class="fa fa-desktop"></i> 
                                        </div>                                   
                                    </li>

                                    <li>
                                        <div class="hover">
                                            <img src="<?php echo base_url();?>/assets/img/gallery/6.jpg" alt=""/>                               
                                            <a href="<?php echo base_url();?>/assets/img/gallery/6.jpg" class="ligbox-image" title="Image"><div class="overlay"></div></a>
                                        </div>                                   
                                        <div class="info">
                                            Classic Restaurant - Css3/Html5
                                            <i class="fa fa-tablet"></i>
                                            <i class="fa fa-desktop"></i> 
                                        </div>                                   
                                    </li>
                                </ul>   
                                <!--End Carousel Gallery-->  
                            </div>                    
                        </div>
                    </div>
                </div>
                <!-- End Info Resalt-->
            </section>   
            <!-- End content info - Portfolio Carousel Section--> 