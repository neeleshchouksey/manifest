<section class="container-fluid page-cover portfolio-cover-img">
  <div class="container-fluid">
    <div class="container">
      <div class="page-heading">
        <h3>Web Design</h3>
        <h4>We help your make e marketing esier.</h4>
        <p> Contrary to popular belief, Lorem Ipsum is not simply random text. 
          It has roots in a piece of classical Latin literature from 45 BC, making
          it over 2000 years old. </p>
      </div>
    </div>
  </div>
</section>
<!--/page cover & testimonail section...
-----------------------------------------------------------------------------------> 
<!----------------------Web design Start--------------------------------->
<section class="page-section theme-bg-gray">
  <div class="container-fluid">
    <div class="container">
      <h4 class="doc_diman">Web Design</h4>
      <div class="row-fluid">
        <div class="span8 pull-left costumize_max_width">
          <div class="pagination portfolio-type"> </div>
          <ul class="thumbnails">
            <li data-type="design" data-id="1" class="span6 view view-tenth"> <img src="assets/images/portfolio/webdesign.jpg"  alt="web desing">
              <div class="mask">
                <h2>DOCTOR ON DEMAND </h2>
                <p> An app that allow patient to get appointment, take prescription, and pay online fee to the doctors. </p>
                <a href="portfolio-detail.htm" class="btn-light">More</a> </div>
            </li>
            <li data-type="design" data-id="2" class="span6 view view-tenth"> <img src="assets/images/portfolio/seo.jpg"  alt="">
              <div class="mask">
                <h2> SEO(Search Engine Optimization)</h2>
                <p> Contrary to popular belief, Lorem Ipsum is not simply random text. </p>
                <a href="portfolio-detail.htm" class="btn-light "> More </a> </div>
            </li>
          </ul>
          <ul class="thumbnails">
            <li data-type="design" data-id="1" class="span6 view view-tenth"> <img src="assets/images/portfolio/webdesign.jpg"  alt="web desing">
              <div class="mask">
                <h2>DOCTOR ON DEMAND </h2>
                <p> An app that allow patient to get appointment, take prescription, and pay online fee to the doctors. </p>
                <a href="portfolio-detail.htm" class="btn-light">More</a> </div>
            </li>
            <li data-type="design" data-id="2" class="span6 view view-tenth"> <img src="assets/images/portfolio/seo.jpg"  alt="">
              <div class="mask">
                <h2> SEO(Search Engine Optimization)</h2>
                <p> Contrary to popular belief, Lorem Ipsum is not simply random text. </p>
                <a href="portfolio-detail.htm" class="btn-light "> More </a> </div>
            </li>
          </ul>
          <ul class="thumbnails">
            <li data-type="design" data-id="1" class="span6 view view-tenth"> <img src="assets/images/portfolio/webdesign.jpg"  alt="web desing">
              <div class="mask">
                <h2>DOCTOR ON DEMAND </h2>
                <p> An app that allow patient to get appointment, take prescription, and pay online fee to the doctors. </p>
                <a href="portfolio-detail.htm" class="btn-light">More</a> </div>
            </li>
            <li data-type="design" data-id="2" class="span6 view view-tenth"> <img src="assets/images/portfolio/seo.jpg"  alt="">
              <div class="mask">
                <h2> SEO(Search Engine Optimization)</h2>
                <p> Contrary to popular belief, Lorem Ipsum is not simply random text. </p>
                <a href="portfolio-detail.htm" class="btn-light "> More </a> </div>
            </li>
          </ul>
        </div>
       
        <!----portfolio-detail-categories start ----------------------->
        
		<?php include "portfolio-detail-categories.php"; ?>
		 
		<!----portfolio-detail-categories end ----------------------->

        <div class="span3 pull-right"> </div>
        <div id="right-panel-post" class="span3 pull-right shadow-block">
          <h3 class="cat-title heading-a border-theme-l"> Recent Posted</h3>
          <ul class="r-post-list">
            <li> <a href="#">
              <p>The Top H	ighest Paying Technical Job in </p>
              <small>22 march 2015</small> </a> </li>
            <li> <a href="#">
              <p>History and Performance of HTML</p>
              <small>01 march 2015</small> </a> </li>
            <li> <a href="#">
              <p>Lorem ipsum dolor sit amet,</p>
              <small>22 Jan. 2014</small> </a> </li>
            <li> <a href="#">
              <p>Lorem ipsum dolor sit amet,</p>
              <small>22 Jan. 2014</small> </a> </li>
            <li> <a href="#">
              <p>Lorem ipsum dolor sit amet,</p>
              <small>22 Jan. 2014</small> </a> </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  </div>
</section>
