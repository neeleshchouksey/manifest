<div id="right-panel-cat" class="span3 pull-right shadow-block">
	<h3 class="cat-title heading-a border-theme-l"> Catagories</h3>
	<ul class="cat-list">
		<li> 
			<a href="<?php echo site_url('mi/web-design');?>"><i class="fa fa-chevron-right"></i>Web Design</a>
		</li>
		<li> 
			<a href="<?php echo site_url('mi/web-development');?>"><i class="fa fa-chevron-right"></i>Web Development</a>
		</li>
		<li> 
			<a href="<?php echo site_url('mi/seo');?>"><i class="fa fa-chevron-right"></i>SEO</a> 
		</li>
		<li> 
			<a href="<?php echo site_url('mi/digital-marketing');?>"><i class="fa fa-chevron-right"></i>Digital marketing</a> 
		</li>
	</ul>
</div>