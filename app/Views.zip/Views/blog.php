                <!-- Info section Title-->
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h1>Blog</h1>
                            <p class="lead">Pellentesque habitant morbi tristique senectus et netus et malesuada fames.</p>
                        </div>
                    </div>
                </div>            
                <!-- End Info section Title--> 
            </header>
            <!-- End Header Section-->

            <!-- End content info - White Section-->
            <section class="content_info">
                <!-- Info Resalt-->
                <div class="paddings">
                    <div class="container">
                        <div class="row">
                            <!-- Post-->
                            <div class="col-md-9">
                                <div class="row">
                                    <!-- Item Post 01-->
                                    <div class="col-sm-6 col-md-6">
                                        <div class="blog-content">
                                            <div class="entry-header">
                                                <div class="blog-image">
                                                    <img class="img-responsive" src="<?php echo base_url();?>/assets/images/gallery/1.jpg" alt="">
                                                    <div class="more-link">
                                                        <a href="#"><i class="fa fa-plus"></i></a>
                                                    </div>
                                                </div>                          
                                                <div class="post-date">
                                                    <h3>27<span>August</span></h3>
                                                </div>                          
                                            </div>
                                            <div class="entry-content">                         
                                                <h3 class="entry-title"><a href="#">Adipisicing elit, sed do eiusmod tempor</a></h3>
                                                <ul class="entry-meta">
                                                    <li><a href="#"><i class="fa fa-user"></i> By: Admin <span>/</span></a></li>
                                                    <li><a href="#"><i class="fa fa-tags"></i> Desing <span>/</span></a></li>
                                                    <li><a href="#"><i class="fa fa-comments"></i> 2 Comments</a></li>
                                                </ul>
                                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                                            </div>
                                        </div>
                                    </div>
                                     <!-- End Item Post 01-->

                                    <!-- Item Post 01-->
                                    <div class="col-sm-6 col-md-6">
                                        <div class="blog-content">
                                            <div class="entry-header">
                                                <div class="blog-image">
                                                    <img class="img-responsive" src="<?php echo base_url();?>/assets/images/gallery/2.jpg" alt="">
                                                    <div class="more-link">
                                                        <a href="#"><i class="fa fa-plus"></i></a>
                                                    </div>
                                                </div>                          
                                                <div class="post-date">
                                                    <h3>27<span>August</span></h3>
                                                </div>                          
                                            </div>
                                            <div class="entry-content">                         
                                                <h3 class="entry-title"><a href="#">Adipisicing elit, sed do eiusmod tempor</a></h3>
                                                <ul class="entry-meta">
                                                    <li><a href="#"><i class="fa fa-user"></i> By: Gama <span>/</span></a></li>
                                                    <li><a href="#"><i class="fa fa-tags"></i> Photograph <span>/</span></a></li>
                                                    <li><a href="#"><i class="fa fa-comments"></i> 5 Comments</a></li>
                                                </ul>
                                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                                            </div>
                                        </div>
                                    </div>
                                     <!-- End Item Post 01-->

                                     <!-- Item Post 01-->
                                    <div class="col-sm-6 col-md-6">
                                        <div class="blog-content">
                                            <div class="entry-header">
                                                <div class="blog-image">
                                                    <img class="img-responsive" src="<?php echo base_url();?>/assets/images/gallery/3.jpg" alt="">
                                                    <div class="more-link">
                                                        <a href="#"><i class="fa fa-plus"></i></a>
                                                    </div>
                                                </div>                          
                                                <div class="post-date">
                                                    <h3>27<span>August</span></h3>
                                                </div>                          
                                            </div>
                                            <div class="entry-content">                         
                                                <h3 class="entry-title"><a href="#">Adipisicing elit, sed do eiusmod tempor</a></h3>
                                                <ul class="entry-meta">
                                                    <li><a href="#"><i class="fa fa-user"></i> By: Admin <span>/</span></a></li>
                                                    <li><a href="#"><i class="fa fa-tags"></i> Development <span>/</span></a></li>
                                                    <li><a href="#"><i class="fa fa-comments"></i> 3 Comments</a></li>
                                                </ul>
                                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                                            </div>
                                        </div>
                                    </div>
                                     <!-- End Item Post 01-->

                                     <!-- Item Post 01-->
                                    <div class="col-sm-6 col-md-6">
                                        <div class="blog-content">
                                            <div class="entry-header">
                                                <div class="blog-image">
                                                    <img class="img-responsive" src="<?php echo base_url();?>/assets/images/gallery/4.jpg" alt="">
                                                    <div class="more-link">
                                                        <a href="#"><i class="fa fa-plus"></i></a>
                                                    </div>
                                                </div>                          
                                                <div class="post-date">
                                                    <h3>27<span>August</span></h3>
                                                </div>                          
                                            </div>
                                            <div class="entry-content">                         
                                                <h3 class="entry-title"><a href="#">Adipisicing elit, sed do eiusmod tempor</a></h3>
                                                <ul class="entry-meta">
                                                    <li><a href="#"><i class="fa fa-user"></i> By: Admin <span>/</span></a></li>
                                                    <li><a href="#"><i class="fa fa-tags"></i> Art <span>/</span></a></li>
                                                    <li><a href="#"><i class="fa fa-comments"></i> 3 Comments</a></li>
                                                </ul>
                                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                                            </div>
                                        </div>
                                    </div>
                                     <!-- End Item Post 01-->
                                </div>
                            </div>
                            <!-- Post-->

                            <!-- Sidebars Left Sidebar-->
                            <div class="col-md-3 sidebars">
                                <aside>
                                    <h4>Searh Sidebar</h4>
                                    <form class="search">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-search"></i>
                                            </span>
                                            <input class="form-control" placeholder="Search..." name="email"  type="email" required="required">
                                            <span class="input-group-btn">
                                                <button class="btn btn-primary" type="submit" name="subscribe" >Go!</button>
                                            </span>
                                        </div>
                                    </form>    
                                </aside>
                                
                                <aside>
                                    <h4>Categories</h4>
                                    <ul class="list">
                                        <li><i class="fa fa-check"></i><a href="#">Design</a></li>
                                        <li><i class="fa fa-check"></i><a href="#">Photos</a></li>
                                        <li><i class="fa fa-check"></i><a href="#">Videos</a></li>
                                        <li><i class="fa fa-check"></i><a href="#">Lifestyle</a></li>
                                        <li><i class="fa fa-check"></i><a href="#">Technology</a></li>
                                    </ul>
                                </aside>                         
                          
                                <aside>
                                    <h4>Wiget Text</h4>
                                    <p>Nulla nunc dui, tristique in semper vel, congue sed ligula. Nam dolor ligula, faucibus id sodales in, auctor fringilla libero. Nulla nunc dui, tristique in semper vel. Nam dolor ligula, faucibus id sodales in, auctor fringilla libero.</p>
                                </aside>

                                <aside>
                                    <h4>Archives</h4>
                                    <ul class="list">
                                        <li><i class="fa fa-check"></i><a href="#">Design</a></li>
                                        <li><i class="fa fa-check"></i><a href="#">Photos</a></li>
                                        <li><i class="fa fa-check"></i><a href="#">Videos</a></li>
                                        <li><i class="fa fa-check"></i><a href="#">Lifestyle</a></li>
                                        <li><i class="fa fa-check"></i><a href="#">Technology</a></li>
                                    </ul>
                                </aside>   
                            </div>
                            <!-- End Sidebars Left Sidebar-->

                            <div class="col-md-12">
                                <ul class="pagination">
                                    <li><a href="#">«</a></li>
                                    <li class="active"><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#">»</a></li>
                                </ul>
                            </div>  
                        </div>
                    </div>
                </div>
                <!-- End Info Resalt-->
            </section>   
            <!-- End content info - White Section--> 