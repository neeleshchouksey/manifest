<section class="page-cover About-cover-img">
  <div class="container-fluid">
    <div class="container">
      <div class="page-heading">
        <h3>PROCESS</h3>
        <h4>We keep up transparency policy in our network</h4>
        <p> Our process methodology build a smooth communication path for clients as well as our team members </p>
      </div>
    </div>
  </div>
</section>
<section class="page-section coo_otr" >
  <div  class="container-fluid">
    <div class="container">
      <div class="page-heading"> </div>
      <div class="spacer-mini"></div>
      <div class="container">
        <div class=" row-fluid">
          <div class="span12">
            <div class="border pull-right thumb-right"> <a href="JavaScript:Void(0)" class="shadow"> 
              <!--<img  width="250" src="assets/images/home-about/about-us.jpg" title="About Us">--> 
              </a> </div>
            <h3>Process</h3>
            <br />
            <p class="justify process_prg">Manifest understands the dynamism and flexibility required to cater the requirement of each client, any rigid process or methodology might prove to be an obstruction in achieving the optimum results. We follow different models depending on the environment of the project. For all mid size projects at Manifest we follow a blend of Waterfall and Scrum model to get an edge and for large ongoing projects we strictly adhere to Scrum model. The process at Manifest adopts the spiral iterative methodology where the entire software development project cycle has to go through one or more iterations of all project stages. We have defined processes for queries, requirements specifications, analysis, design, development, testing, deployment, and maintenance. Our adopted process enables our client to witnessa steady growth of the solution starting from its inception to its implementation. </p>
              <ul class="bullet_process check_ic check_right span8">
                <li><i class="fa fa-circle-o"></i>Small Projects</li>
                <li><i class="fa fa-circle-o"></i>Medium Projects</li>
                <li><i class="fa fa-circle-o"></i>Large Projects</li>
                <li><i class="fa fa-circle-o"></i>Offshore Delivery Model</li>
              </ul>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>