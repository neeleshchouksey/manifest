<section class="page-cover About-cover-img">
  <div class="container-fluid">
    <div class="container">
      <div class="page-heading">
        <h3>DESIGN & HTML</h3>
        <h4>Effective strategy give startup to the ultimate goal</h4>
        <p>We design clients dreams & ideas for the success of their business</p>
      </div>
    </div>
  </div>
</section>
<section class="page-section coo_otr" >
  <div  class="container-fluid">
    <div class="container">
      <div class="page-heading"> </div>
      <div class="spacer-mini"></div>
      <div class="container">
        <div class=" row-fluid">
          <div class="span12">
            <div class="border pull-right thumb-right"> <a href="#" class="shadow"> 
              <!--<img  width="250" src="assets/images/home-about/about-us.jpg" title="About Us">--> 
              </a> </div>
            <h3>Design and HTML</h3>
            <br />
            <p class="justify process_prg">At Manifest Infotech, our team of talented web designers acquire the knowledge about you design
              requirement and produce the best quality Website Design with creative design, implementing innovative ideas and creative
              art work. Keeping looks your website professional, as it reflect the image of your business and show your online presence.</p>
            <br/>
            <p class="process_prg justify">We are among the top of<b> Web Design Company in indore. </b></p>
            <br/>
            <p class="justify process_prg">Our team of web designers has experience in different types of websites (web design services) 
              which includes photo gallery, audio, video and other media type edition, design layouts are depends on your requirements
              and vision. We gather information about your design needs and our team translates it into reality. </p>
            <p class="justify process_prg">To make better use of allotted project time and resources, design should include a few layouts and
              widgets at different sizes. Responsive Web design means letting go of pixel-perfect designs. Making those designs work on 
              desktop browsers is challenging enough, but when we think in terms of flexible widgets on a flowing grid, the number of
              designs needed becomes manageable.</p>
            <p class="justify process_prg">Let the medium of HTML enhance the qualities of the design using a fluid layout in all environments.
              Creating the states for each browser width is a huge waste of time - instead focus on the totality of the user experience. </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>