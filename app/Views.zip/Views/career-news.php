  <div class="span4 pull-right shadow-block">
	<h1 class="heading-a border-theme-l"> Career News</h1>
	<div class="spacer-mini2"></div>
	<ul class="c-news-list">
	   <li>
		  <a href="#">
			 <img src="assets/images/career/news-thumb-1.png" align="left" />
			 <h3>25</h3>
			 <span>Dec.</span>
			 <h4>Lorem ipsum dolor sit amet,</h4>
			 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p>
		  </a>
	   </li>
	   <li>
		  <a href="#">
			 <img src="assets/images/career/news-thumb-2.png" align="left" />
			 <h3>25</h3>
			 <span>Dec.</span>
			 <h4>Lorem ipsum dolor sit amet,</h4>
			 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p>
		  </a>
	   </li>
	   <li>
		  <a href="#">
			 <img src="assets/images/career/news-thumb-3.png" align="left" />
			 <h3>25</h3>
			 <span>Dec.</span>
			 <h4>Lorem ipsum dolor sit amet,</h4>
			 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p>
		  </a>
	   </li>
	   <li>
		  <a href="#">
			 <img src="assets/images/career/news-thumb-1.png" align="left" />
			 <h3>25</h3>
			 <span>Dec.</span>
			 <h4>Lorem ipsum dolor sit amet,</h4>
			 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p>
		  </a>
	   </li>
	</ul>
 </div>