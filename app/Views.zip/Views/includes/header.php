<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Basic -->
        <meta charset="utf-8">
        <title><?php echo $title; ?></title> 

        <link href="https://plus.google.com/113088163173614486012" rel="publisher" />
        <meta charset="utf-8">
        <meta name="google-site-verification" content="_xlmTxc8ZqiFlmTy_NVn6V4_wBVrve5gHpcbaQdk7FE" />
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta name="application-name" content="Software development company">
        
        <meta name="keywords" content="<?php echo $keywords; ?>">
        <meta name="description" content="<?php if($description!="")echo $description; ?>">
        <meta name="author" content="Manifest Infotech Pvt. Ltd.">
        <link rel = "canonical" href="http://manifestinfotech.com"/>

        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <base href="<?php echo base_url();?>/">

        <!-- Theme CSS -->
        <link type="text/css" media="screen" rel="stylesheet" href="<?php echo base_url();?>/assets/css/style.css"/>
        <!-- Responsive CSS -->
        <link type="text/css" media="screen" rel="stylesheet" href="<?php echo base_url();?>/assets/css/theme-responsive.css"/>
        <!-- Skins Theme -->
        <link type="text/css" media="screen" rel="stylesheet" href="<?php echo base_url();?>/assets/css/skins/blue/blue.css" class="skin_color"/>

        <!-- Favicons -->
        <link rel="shortcut icon" href="<?php echo base_url();?>/assets/images/common-img/favicon.ico">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>/assets/im/icons/apple-touch-icon.png">
        <link rel="apple-touch-icon" sizes="72x72" href="<?php echo base_url();?>/assets/im/icons/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="<?php echo base_url();?>/assets/im/icons/apple-touch-icon-114x114.png">   

        <!--[if IE]>
            <link rel="stylesheet" href="css/ie/ie.css">
        <![endif]-->

        <!--[if lte IE 8]>
            <script src="js/responsive/html5shiv.js"></script>
            <script src="js/responsive/respond.js"></script>
        <![endif]-->
    </head>

    <body> 
        <!-- layout-->
        <div id="layout" class="layout-wide">
            <!-- Header Section-->
            <header class="section_title-02">
                <!-- nav_logo Section-->
                <div class="nav_logo fadeInDown">            
                    <div class="container">
                        <div class="row">
                            <!-- Logo-->
                            <div class="col-md-3 logo">
                                <a href="<?php echo base_url();?>" title="Back to Home"> 
                                    <img src="<?php echo base_url();?>/assets/images/common-img/logo.png" alt="Logo" class="logo_img" >
                                </a>
                            </div>
                            <!-- End Logo-->
                                                          
                            <!-- Nav-->
                            <nav class="col-md-9">
                                <!-- Menu-->
                                <ul id="menu" class="sf-menu">
                                    <li>
                                        <a href="">HOME</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo site_url();?>/aboutus">ABOUT US</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo site_url();?>/services">SERVICES</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo site_url();?>/portfolio">WORK</a>
                                    </li>    
                                     <li>
                                        <a href="<?php echo site_url();?>/blog">BLOG</a>
                                    </li>                                         
                                    <li>
                                        <a href="<?php echo site_url();?>/mi/contact">CONTACT</a>
                                    </li>
                                </ul>
                                <!-- End Menu-->
                            </nav>
                            <!-- End Nav-->         
                        </div>
                    </div>
                </div>
                <!-- End nav_logo Section-->













