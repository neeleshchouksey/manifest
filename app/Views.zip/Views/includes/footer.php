<!-- footer-->
            <footer class="">
                <div class="container">
                    <div class="row">
                        
                        <!-- Recent Links -->
                        <div class="col-md-2">
                            <h3>TECHNOLOGIES</h3>
                            <ul>
                                <li><i class="fa fa-check"></i><a href="<?php echo site_url();?>/portfolio">Work</a></li>
                                <li><i class="fa fa-check"></i><a href="<?php echo site_url();?>/aboutus">About Us</a></li>
                                <li><i class="fa fa-check"></i><a href="<?php echo site_url();?>/services">Services</a></li>
                                <li><i class="fa fa-check"></i><a href="<?php echo site_url();?>/mi/contact">Contact Us</a></li>
                            </ul>
                        </div>
                        <!-- End Recent Links-->

                        <!-- Recent Links -->
                        <div class="col-md-2">
                            <h3>RECENT LINKS</h3>
                            <ul>
                                <li><i class="fa fa-check"></i><a href="<?php echo site_url();?>/aboutus">Work</a></li>
                                <li><i class="fa fa-check"></i><a href="<?php echo site_url();?>/aboutus">About Us</a></li>
                                <li><i class="fa fa-check"></i><a href="<?php echo site_url();?>/aboutus">Services</a></li>
                                <li><i class="fa fa-check"></i><a href="<?php echo site_url();?>/aboutus">Contact Us</a></li>
                            </ul>
                        </div>
                        <!-- End Recent Links-->

                        <!-- Recent links-->
                        <div class="col-md-2">
                            <h3>NEW BLOGS</h3>
                            <div class="twitts"></div>                        
                        </div>
                        <!-- End Recent links-->

                        <!-- Contact Us-->
                        <div class="col-md-3">
                           <h3>CONTACT US</h3>
                           <ul class="contact_footer">
                                <li>
                                    <i class="fa fa-envelope"></i> <a href="mailto:info@manifestinfotech.com">info@manifestinfotech.com</a>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:info@manifestinfotech.com">nchouksey@manifestinfotech.com</a>
                                </li>
                                <li>
                                    <i class="fa fa-headphones"></i> <a href="#">+91 731 3582993, <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp+91 7771983222</a>
                                 </li>
                                <li class="location">
                                    <i class="fa fa-home"></i> <a href="#"> B-319, Tulsi Nagar, Indore<br></a>
                                </li>                                   
                            </ul>
                        </div>
                        <!-- Contact Us-->

                        <!-- Social Section-->
                        <div class="col-md-2">
                            <h3>FOLLOW US</h3>
                            <ul class="social">
                                <li class="linkedin"><a href="https://in.linkedin.com/company/manifest-infotech" target="_blank" Title="Linkedin"><span><i class="fa fa-linkedin"></i></span>Linkedin</a></li>
                                <li class="twitter"><a href="https://twitter.com/Manifest_info" target="_blank" Title="Twitter"><span><i class="fa fa-twitter"></i></span>Twitter</a></li>
                                <li class="instagram"><a href="https://www.instagram.com/manifestinfotech/" target="_blank" Title="Instagram"><span><i class="fa fa-instagram"></i></span>Instagram</a></li>
                                <li class="facebook"><a href="https://www.facebook.com/manifestinfotech" target="_blank" Title="Facebook"><span><i class="fa fa-facebook"></i></span>Facebook</a></li>
                                <li class="pinterest"><a href="https://www.pinterest.com/archananchoukse/" target="_blank" Title="Pinterest"><span><i class="fa fa-pinterest"></i></span>Pinterest</a></li>
                            </ul>
                        </div>
                        <!-- End Social Section-->
                        
                    </div>
                </div>
            </footer>      
            <!-- End footer-->

            <!-- footer-->
            <footer class="coopring">
                <p>&copy; 2012 Manifest Infotech Pvt. Ltd. | All rights reserved.</p>
            </footer>      
            <!-- End footer-->
        </div>
        <!-- End layout-->
   
        <!-- ======================= JQuery libs =========================== -->
        <!-- jQuery local-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.js"></script>
        <!--Nav-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/nav/tinynav.js"></script> 
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/nav/superfish.js"></script> 
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/nav/hoverIntent.js"></script>  
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/nav/jquery.sticky.js"></script>                                               
        <!--Totop-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/totop/jquery.ui.totop.js" ></script>  
        <!--Slide Revolution-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/rs-plugin/js/jquery.themepunch.tools.min.js" ></script>      
        <script type='text/javascript' src='<?php echo base_url();?>/assets/js/rs-plugin/js/jquery.themepunch.revolution.min.js'></script>  
        <!--owl-carousel-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/carousel/owl.carousel.js"></script>    
        <!--Ligbox--> 
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/fancybox/jquery.fancybox.pack.js"></script>  
        <!--Gallery Grid--> 
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/gallery/modernizr.custom.26633.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/gallery/jquery.gridrotator.js"></script>     
        <!--Minislider Team-->         
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/team/modernizr.custom.63321.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/team/jquery.catslider.js"></script> 
        <!--Filters-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/filters/jquery.isotope.js" ></script>   
        <!--Theme Options-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/theme-options/theme-options.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/theme-options/jquery.cookies.js"></script> 
        <!-- Twitter Feed-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/twitter/jquery.tweet.js"></script>   
        <!-- WOW-master-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/animations/wow.min.js"></script> 
        <!-- Parallax-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/parallax/jquery.inview.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/parallax/nbw-parallax.js"></script>                           
        <!-- Bootstrap.js-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/bootstrap/bootstrap.js"></script>
        <!--fUNCTIONS-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/main.js"></script>
        <!-- ======================= End JQuery libs =========================== -->
        
        <!--Slider Function-->
        <script type="text/javascript">
            jQuery(document).ready(function() {
               jQuery('.tp-banner').revolution(
                {
                    delay:15000,
                    startwidth:1170,
                    startheight:500,
                    hideThumbs:10,
                    fullWidth:"on",
                    fullScreen:"on",
                    fullScreenOffsetContainer: ""
                });
            });
        </script>
        <!--End Slider Function-->
  </body>
</html>