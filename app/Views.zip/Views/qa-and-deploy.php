<section class="page-cover About-cover-img">
  <div class="container-fluid">
    <div class="container">
      <div class="page-heading">
        <h3>QA & DEPLOY</h3>
        <h4>Effective strategy give startup to the ultimate goal</h4>
        <p>Our success is in delivering quality services with full efficiency</p>
      </div>
    </div>
  </div>
</section>
<section class="page-section coo_otr" >
  <div  class="container-fluid">
    <div class="container">
      <div class="page-heading"> </div>
      <div class="spacer-mini"></div>
      <div class="container">
        <div class=" row-fluid">
          <div class="span12">
            <div class="border pull-right thumb-right"> <a href="JavaScript:Void(0)" class="shadow"> 
              <!--<img  width="250" src="assets/images/home-about/about-us.jpg" title="About Us">--> 
              </a> </div>
            <h3>QA and Deploy</h3>
            <br />
            <p class="justify process_prg">In our agile and responsive process, the design must live on a flexible grid. The widgets need to be planned out and prototyped
              by the developers, and they need to be tested along the way. The code also needs to be optimized to ensure that the widgets are the smallest possible unit.
              The widgets can be easily inserted and removed from layouts that were not originally planned for, and testing these options grants peace of mind. Constant 
              collaboration between the developer, designer and strategist circumvents issues with the inevitable changes. With the different members of the team on thesame 
              page, problems are identified and resolved earlier in the process.</p>
            <br/>
            <ul class="bullet_process check_right check_ic span8">
				  <li><i class="fa fa-circle-o"></i>Web 2.0 design implementation with fast loading optimization.</li>
				  <li><i class="fa fa-circle-o"></i>W3C validate implementation with xHTML 1.0 or HTML 4.01 Transitional and CSS level 2.1 minimum.</li>
				  <li><i class="fa fa-circle-o"></i>Cross browser compatible with all major browsers IE, Mozilla, Chrome, Safari and others.</li>
				  <li><i class="fa fa-circle-o"></i>DIV based (Table less) implementation.</li>
				  <li><i class="fa fa-circle-o"></i>Use of single CSS file to define overall colour theme and style definitions and for making cross browser supported.</li>
				  <li><i class="fa fa-circle-o"></i>Search Engine Optimization Semantic and neat & clean coding structure with well commented.</li>
			  </ul>	
          </div>
        </div>
      </div>
    </div>
  </div>
</section>