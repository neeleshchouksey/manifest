<!--map block-->
  <div id="googleMap" class="map-home"></div>
<!--map end--> 