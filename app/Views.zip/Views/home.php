<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Basic -->
        <meta charset="utf-8">
        <title><?php echo $title; ?></title>   
        <meta name="keywords" content="HTML5 Template" />
        <meta name="description" content="Jekas is a Software, Studio and Corporate Responsive Template">
        <meta name="author" content="iwthemes.com">  

        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <base href="<?php echo base_url();?>/">

        <!-- Theme CSS -->
        <link type="text/css" media="screen" rel="stylesheet" href="<?php echo base_url();?>/assets/css/style.css"/>
        <!-- Responsive CSS -->
        <link type="text/css" media="screen" rel="stylesheet" href="<?php echo base_url();?>/assets/css/theme-responsive.css"/>
        <!-- Skins Theme -->
        <link type="text/css" media="screen" rel="stylesheet" href="<?php echo base_url();?>/assets/css/skins/blue/blue.css" class="skin_color"/>

        <!-- Favicons -->
        <link rel="shortcut icon" href="<?php echo base_url();?>/assets/images/common-img/favicon.ico">
        <link rel="apple-touch-icon" href="<?php echo base_url();?>/assets/im/icons/apple-touch-icon.png">
        <link rel="apple-touch-icon" sizes="72x72" href="<?php echo base_url();?>/assets/im/icons/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="<?php echo base_url();?>/assets/im/icons/apple-touch-icon-114x114.png"> 

        <!--[if IE]>
            <link rel="stylesheet" href="css/ie/ie.css">
        <![endif]-->

        <!--[if lte IE 8]>
            <script src="js/responsive/html5shiv.js"></script>
            <script src="js/responsive/respond.js"></script>
        <![endif]-->
    </head>
    <body> 
        

        <!-- layout-->
        <div id="layout" class="layout-wide">
            <!-- Header Section-->
            <header class="slide">
               <!-- nav_logo Section-->
                <div class="nav_logo fadeInDown">            
                    <div class="container">
                        <div class="row">
                            <!-- Logo-->
                            <div class="col-md-3 logo">
                                <a href="<?php echo base_url();?>" title="Back to Home">
                                    <img src="<?php echo base_url();?>/assets/images/common-img/logo.png" alt="Logo" class="logo_img">
                                </a>
                            </div>
                            <!-- End Logo-->
                                                          
                            <!-- Nav-->
                            <nav class="col-md-9">
                                <!-- Menu-->
                                <ul id="menu" class="sf-menu">
                                    <li>
                                        <a href="">HOME</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo site_url();?>/aboutus">ABOUT US</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo site_url();?>/services">SERVICES</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo site_url();?>/portfolio">WORK</a>
                                    </li>    
                                     <li>
                                        <a href="<?php echo site_url();?>/blog">BLOG</a>
                                    </li>                                         
                                    <li>
                                        <a href="<?php echo site_url();?>/mi/contact">CONTACT</a>
                                    </li>
                                </ul>
                                <!-- End Menu-->
                            </nav>
                            <!-- End Nav-->         
                        </div>
                    </div>
                </div>
                <!-- End nav_logo Section-->
                
                <!-- Slide Section-->    
                <div class="tp-banner-container">
                    <div class="tp-banner" >
                        <ul>
                            <!-- SLIDE  01-->
                            <li data-transition="slidehorizontal" data-slotamount="7" data-masterspeed="1000"  data-fstransition="fade" data-fsmasterspeed="1000" data-fsslotamount="7">

                                <!-- LAYER NR. 1 -->
                                <div class="tp-caption tp-fade fadeout fullscreenvideo"
                                    data-x="0"
                                    data-y="0"
                                    data-speed="1000"
                                    data-start="1100"
                                    data-easing="Power4.easeOut"
                                    data-endspeed="1500"
                                    data-endeasing="Power4.easeIn"
                                    data-autoplay="true"
                                    data-autoplayonlyfirsttime="false"
                                    data-nextslideatend="true"
                                    data-forceCover="1"
                                    data-dottedoverlay="twoxtwo"
                                    data-aspectratio="16:9"
                                    data-forcerewind="on"
                                    style="z-index: 2">

                                    <video class="video-js vjs-default-skin" preload="none" width="100%" height="100%"
                                    poster='<?php echo base_url();?>/assets/images/slide/slides/video-bg.png' data-setup="{}">
                                    <source src='<?php echo base_url();?>/assets/images/video/video-slide.webm' type='video/webm' />
                                    </video>
                                </div>

                                <!-- LAYER NR. 2 -->
                                <div class="tp-caption large_bold_white tp-fade fadeout tp-resizeme"
                                    data-x="30"
                                    data-y="120" data-voffset="0"
                                    data-speed="500"
                                    data-start="1000"
                                    data-easing="Power4.easeOut"
                                    data-splitin="chars"
                                    data-splitout="chars"
                                    data-elementdelay="0.05"
                                    data-endelementdelay="0.05"
                                    data-endspeed="300"
                                    style="z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;">Design and Development
                                </div>
                                <!-- LAYER NR. 2 -->

                                <!-- LAYER NR. 3 -->
                                <div class="tp-caption medium_light_white tp-fade fadeout tp-resizeme"
                                    data-x="30"
                                    data-y="195" data-voffset="120"
                                    data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                    data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                    data-speed="500"
                                    data-start="1800"
                                    data-easing="Power3.easeInOut"
                                    data-splitin="words"
                                    data-splitout="words"
                                    data-elementdelay="0.12"
                                    data-endelementdelay="0.12"
                                    data-endspeed="300"
                                    style="z-index: 5; max-width: auto; max-height: auto; white-space: nowrap;">Ipad And Android Devices
                                </div>
                                <!-- LAYER NR. 3 -->
                            </li>
                             <!-- END SLIDE  01-->

                            <!-- SLIDE  02-->
                            <li data-transition="zoomout" data-slotamount="7" data-masterspeed="1000" >
                                <!-- MAIN IMAGE -->
                                <img src="<?php echo base_url();?>/assets/images/slide/slides/1.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
                                <!-- LAYERS -->

                                <!-- LAYER NR. 1 -->
                                <div class="tp-caption large_bold_white large_text lft tp-resizeme"
                                    data-x="right"
                                    data-y="120" data-voffset="0"
                                    data-speed="500"
                                    data-start="1000"
                                    data-easing="Power4.easeOut"
                                    data-splitin="chars"
                                    data-splitout="chars"
                                    data-elementdelay="0.05"
                                    data-endelementdelay="0.05"
                                    data-endspeed="300"
                                    style="z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;">Font Awesome Icons
                                </div>
                                <!-- LAYER NR. 1 -->

                                <!-- LAYER NR. 2 -->
                                <div class="tp-caption medium_light_white large_text lft tp-resizeme"
                                    data-x="right"
                                    data-y="195" data-voffset="120"
                                    data-speed="500"
                                    data-start="1800"
                                    data-easing="Power3.easeInOut"
                                    data-splitin="words"
                                    data-splitout="words"
                                    data-elementdelay="0.12"
                                    data-endelementdelay="0.12"
                                    data-endspeed="300"
                                    style="z-index: 5; max-width: auto; max-height: auto; white-space: nowrap;">Our Most Powerfull Features Ever
                                </div>
                                <!-- LAYER NR. 2 -->

                            </li>
                            <!-- END SLIDE  02-->

                            <!-- SLIDE  03-->
                            <li data-transition="zoomout" data-slotamount="7" data-masterspeed="1000"  data-saveperformance="off" >
                                <!-- MAIN IMAGE -->
                                <img src="<?php echo base_url();?>/assets/images/slide/slides/2.jpg"  alt="power-to-creators-slider" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
                                <!-- LAYERS -->

                                <!-- LAYER NR. 1 -->
                                <div class="tp-caption large_text lft tp-resizeme"
                                    data-x="center" data-hoffset="0"
                                    data-y="center" data-voffset="-100"
                                    data-speed="500"
                                    data-start="500"
                                    data-easing="Power2.easeIn"
                                    data-splitin="lines"
                                    data-splitout="none"
                                    data-elementdelay="0.1"
                                    data-endelementdelay="0.1"
                                    data-endspeed="300"
                                    style="z-index: 2; max-width: auto; max-height: auto; white-space: normal;">YOU RELAX, WE CARE FOR YOUR INFORMATION!
                                </div>

                                <!-- LAYER NR. 2 -->
                                <div class="tp-caption small_text lft tp-resizeme"
                                    data-x="center" data-hoffset="0"
                                    data-y="center" data-voffset="-30"
                                    data-speed="300"
                                    data-start="1100"
                                    data-easing="Power2.easeIn"
                                    data-splitin="lines"
                                    data-splitout="none"
                                    data-elementdelay="0.1"
                                    data-endelementdelay="0.1"
                                    data-endspeed="300"
                                    style="z-index: 3; font-size:16px; max-width: auto; max-height: auto; white-space: normal;">WE CARE VERY WELL YOUR INFORMATION, OUR PRIORITY IS TO ENSURE THE SAFETY OF YOUR DATA!
                                </div>

                                <!-- LAYER NR. 3 -->
                                <div class="tp-caption style-caption lfb tp-resizeme"
                                    data-x="center"
                                    data-y="center" data-voffset="30"
                                    data-speed="300"
                                    data-start="1600"
                                    data-easing="Power3.easeInOut"
                                    data-splitin="none"
                                    data-splitout="none"
                                    data-elementdelay="0.1"
                                    data-endelementdelay="0.1"
                                    data-endspeed="300">
                                    <a href="#" class="button">
                                        <span><i class="fa fa-android"></i></span>Android App
                                    </a>
                                </div>
                            </li>
                            <!-- END SLIDE  03-->
                        </ul>
                    </div>
                </div>
                <!-- End Slide Section-->
            </header>
            <!-- End Header Section-->
                
            <!-- Info title-->
            <div class="row info_title wow fadeInUp">
                <div class="vertical_line">
                    <div class="circle_bottom"></div>
                </div>
                <div class="info_vertical animated">
                    <h1>Our <span>skills and expertise</span> Portfolio</h1>
                    <p class="">Our team has a diverse set of <span>skills and expertise,</span> and we have completed a variety of successful projects for clients across different industries.</p>
                </div>
                <div class="vertical_line"></div>

                <!-- <i class="fa fa-cogs right"></i> -->
            </div>
            <!-- End Info title-->

            <!-- End content info - Portfolio Carousel Section-->
            <section class="content_info">
                <!-- Info Resalt-->
                <div class="info_resalt borders">
                    <div class="container wow fadeInUp">
                        <div class="row">
                            <div class="col-md-12">
                                <!-- Carousel Gallery-->        
                                <ul class="owl-carousel carousel-portfolio" id="carousel-portfolio">
                                    <li>
                                        <div class="hover">
                                            <img src="<?php echo base_url();?>/assets/images/gallery/1.jpg" alt=""/>                               
                                            <a href="<?php echo base_url();?>/assets/images/gallery/1.jpg" class="ligbox-image" title="Image"><div class="overlay"></div></a>
                                        </div>                                   
                                        <div class="info">
                                            Responsive Design
                                            <i class="fa fa-tablet"></i>
                                            <i class="fa fa-desktop"></i> 
                                        </div>                                   
                                    </li>   
                                                
                                    <li>
                                        <div class="hover">
                                            <img src="<?php echo base_url();?>/assets/images/gallery/2.jpg" alt=""/>                               
                                            <a href="<?php echo base_url();?>/assets/images/gallery/2.jpg" class="ligbox-image" title="Image"><div class="overlay"></div></a>
                                        </div>                                   
                                        <div class="info">
                                            Vinilo - HTML Template
                                            <i class="fa fa-tablet"></i>
                                            <i class="fa fa-desktop"></i> 
                                        </div>                                   
                                    </li>
                                    
                                    <li>
                                        <div class="hover">
                                            <img src="<?php echo base_url();?>/assets/images/gallery/3.jpg" alt=""/>                               
                                            <a href="<?php echo base_url();?>/assets/images/gallery/3.jpg" class="ligbox-image" title="Image"><div class="overlay"></div></a>
                                        </div>                                   
                                        <div class="info">
                                            Mega Host - Responsive template
                                            <i class="fa fa-tablet"></i>
                                            <i class="fa fa-desktop"></i> 
                                        </div>                                   
                                    </li>  
                                      
                                    <li>
                                        <div class="hover">
                                            <img src="<?php echo base_url();?>/assets/images/gallery/4.jpg" alt=""/>                               
                                            <a href="<?php echo base_url();?>/assets/images/gallery/4.jpg" class="ligbox-image" title="Image"><div class="overlay"></div></a>
                                        </div>                                   
                                        <div class="info">
                                            My Cv - Responsive Resume / CV
                                            <i class="fa fa-tablet"></i>
                                            <i class="fa fa-desktop"></i> 
                                        </div>                                   
                                    </li>
                                          
                                    <li>
                                        <div class="hover">
                                            <img src="<?php echo base_url();?>/assets/images/gallery/5.jpg" alt=""/>                               
                                            <a href="<?php echo base_url();?>/assets/images/gallery/5.jpg" class="ligbox-image" title="Image"><div class="overlay"></div></a>
                                        </div>                                   
                                        <div class="info">
                                            Political - Landing Page
                                            <i class="fa fa-tablet"></i>
                                            <i class="fa fa-desktop"></i> 
                                        </div>                                   
                                    </li>

                                    <li>
                                        <div class="hover">
                                            <img src="<?php echo base_url();?>/assets/images/gallery/6.jpg" alt=""/>                               
                                            <a href="<?php echo base_url();?>/assets/images/gallery/6.jpg" class="ligbox-image" title="Image"><div class="overlay"></div></a>
                                        </div>                                   
                                        <div class="info">
                                            Classic Restaurant - Css3/Html5
                                            <i class="fa fa-tablet"></i>
                                            <i class="fa fa-desktop"></i> 
                                        </div>                                   
                                    </li>
                                </ul>   
                                <!--End Carousel Gallery-->  
                            </div>                    
                        </div>
                    </div>
                </div>
                <!-- End Info Resalt-->
            </section>   
            <!-- End content info - Portfolio Carousel Section--> 

            <!-- Info title-->
            <div class="row info_title wow fadeInUp">
                <div class="vertical_line">
                    <div class="circle_bottom"></div>
                </div>
                <div class="info_vertical animated">
                    <h1><span>Milestones</span> Achieved</h1>
                    <p>“We are proud to have achieved a number of significant milestones since our founding  and are committed to continuing to deliver the best products and services to our clients.”</p>
                </div>
                <div class="vertical_line"></div>

                <!-- <i class="fa fa-coffee left"></i> -->
            </div>
            <!-- End Info title-->

            <!-- End content info - Result Section-->
            <section class="content_info">
                <!-- Info resalt-->
                <div class="info_resalt borders">
                    <div class="container">
                        <div class="row"> 
                            <!-- Left Content -->     
                            <div class="col-md-8 wow fadeInLeft">
                                <!-- Resul Zone-->
                                <div class="row results">
                                    <div class="col-md-3">
                                        <img src="<?php echo base_url();?>/assets/images/icons/team.png">
                                        <h2>55 </h2>
                                        <h5>Team Size</h5>                                
                                    </div>
                                    <div class="col-md-3">
                                        <img src="<?php echo base_url();?>/assets/images/icons/client-served.png">
                                        <h2>120+ </h2>
                                        <h5>Client Served</h5>
                                    </div>
                                    <div class="col-md-3">
                                         <img src="<?php echo base_url();?>/assets/images/icons/completed-projects.png">
                                        <h2>195+ </h2>
                                        <h5>Projects completed</h5>
                                    </div>
                                    <div class="col-md-3">                                    
                                        <img src="<?php echo base_url();?>/assets/images/icons/years-of-experience.png">
                                        <h2>10+ </h2>
                                        <h5>Years of Experience</h5>
                                    </div>
                                    
                                    <span class="arrow_results"></span>
                                </div>   
                                <!-- End Resul Zone-->  
                            </div>
                            <!-- End Left Content -->

                            <!-- Image animation - Right Content -->
                            <div class="col-md-4 wow fadeInRight">
                                <img src="<?php echo base_url();?>/assets/images/common-img/milestones.png" alt="" class="img-responsive">
                            </div>
                            <!-- End Image animation - Right Content-->
                        </div>
                    </div>
                </div>
                <!-- End Info resalt-->
            </section>   
            <!-- End content info - Result Section--> 

            <!-- Info title-->
            <div class="row info_title wow fadeInUp">
                <div class="vertical_line">
                    <div class="circle_bottom"></div>
                </div>
                <div class="info_vertical animated">
                    <h1>Take a look at our <span> Profiles</span></h1>
                    <p>“Let us help you turn your web and app development dreams into a reality. Hire us for our expertise and proven track record of success.”</p>
                </div>
                <div class="vertical_line"></div>

                <!-- <i class="fa fa-tablet right"></i> -->
            </div>
            <!-- End Info title-->

            <!-- End content info - Services Section -->
            <section class="content_info">
                <!-- Services-->
                <section class="info_resalt borders">
                    <div class="container wow fadeInUp">
                        <div class="row text-center">
                            <div class="service-process">
                                <!-- Step 1 -->                        
                                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                                    <div class="thumbnail">
                                        <a href="https://www.linkedin.com/company/manifestinfotech" target="_blank">
                                            <div class="home-profile">
                                                <img src="<?php echo base_url();?>/assets/images/profile/linkedin.jpg" alt="img02">
                                            </div>
                                        </a>
                                    </div>
                                </div>    
                                <!-- End Step 1 -->                      

                                <!-- Step 2 -->                        
                                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                                    <div class="thumbnail">
                                        <a href="https://www.upwork.com/freelancers/~01c1a0c45d9edd9604" target="_blank">
                                            <div class="home-profile">
                                                <img src="<?php echo base_url();?>/assets/images/profile/upwork.jpg" alt="img02">
                                            </div>
                                        </a>
                                    </div>
                                </div>   
                                <!-- End Step 2 -->                       

                                <!-- Step 3 -->
                                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                                    <div class="thumbnail">
                                        <a href="https://clutch.co/profile/manifest-infotech#summary" target="_blank">
                                            <div class="home-profile">
                                                <img src="<?php echo base_url();?>/assets/images/profile/clutch.jpg" alt="img02">
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <!-- End Step 3 -->  

                                <!-- Step 4 -->
                                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                                    <div class="thumbnail">
                                        <a href="https://www.freelancer.in/u/manifestinfo" target="_blank">
                                            <div class="home-profile">
                                                <img src="<?php echo base_url();?>/assets/images/profile/freelancer.jpg" alt="img02">
                                            </div>  
                                        </a>                        
                                    </div>
                                </div>
                                <!-- End Step 4 --> 
                            </div> 

                        </div>
                    </div> 
                </section>  
                <!-- End Services--> 
            </section>   
            <!-- End content info - Services Section --> 

            <!-- Info title-->
            <div class="row info_title wow fadeInUp">
                <div class="vertical_line">
                    <div class="circle_bottom"></div>
                </div>
                <div class="info_vertical animated">
                    <h1>Words of Appreciation From Our <span>Customers</span></h1>
                    <p>“We have received numerous positive reviews and testimonials from happy clients.”</p>
                </div>
                <div class="vertical_line"></div>

                <!-- <i class="fa fa-comment left"></i> -->
            </div>
            <!-- End Info title-->

            <!-- End content info - Testimonials Section-->
            <section class="content_info">
                <!-- testimonials-->
                <section class="info_resalt border_top">  
                    <!-- testimonials Carousel-->            
                    <ul class="owl-carousel carousel-testimonials wow fadeInUp" id="carousel-testimonials">
                        <!-- Item testimonial-->
                        <li>
                            <div class="head-testimonials">
                                <div class="image-testimonials">
                                    <img src="<?php echo base_url();?>/assets/images/client/Doug.jpg" alt="">                        
                                </div>                       
                            </div>
                            <div class="name">
                                <h3>Doug Edmondson</h3>
                            </div>                    
                            <div class="job">
                                <h3>Co-founder at Retirein3</h3>
                            </div>
                            <p>I've worked with Manifest Infotech for over many years. Developers have a solid understanding of development and write clean, concise, functional code. They are very dedicated and when needed put in extra time to meet critical deadlines.</p>
                        </li>
                        <!-- End Item testimonial-->

                        <!-- Item testimonial-->
                        <li>
                            <div class="head-testimonials">
                                <div class="image-testimonials">
                                    <img src="<?php echo base_url();?>/assets/images/client/Alex.jpg" alt="">                        
                                </div>                       
                            </div>
                            <div class="name">
                                <h3>Alex</h3>
                             </div>                    
                            <div class="job">
                                <h3>Director at Revo sys</h3>
                            </div>
                            <p>Working with the team at Manifest Infotech was a pleasure from start to finish. They took the time to understand our business needs and developed a custom web solution that exceeded our expectations. The end result was a professional, user-friendly website that has helped us better serve our customers and grow our business.</p>
                        </li>
                        <!-- End Item testimonial-->

                        <!-- Item testimonial-->
                        <li>
                            <div class="head-testimonials">
                                <div class="image-testimonials">
                                    <img src="<?php echo base_url();?>/assets/images/client/Franck.jpg" alt="">                        
                                </div>                       
                            </div>
                            <div class="name">
                                <h3>Franck</h3>
                            </div>                    
                            <div class="job">
                                <h3>Founder of Collibri</h3>
                            </div>
                            <p>Our company has been working with Manifest Infotech for several years now, and we have always been extremely satisfied with the quality of their work.</p>
                        </li>
                        <!-- End Item testimonial-->

                        <!-- Item testimonial-->
                        <li>
                            <div class="head-testimonials">
                                <div class="image-testimonials">
                                    <img src="<?php echo base_url();?>/assets/images/client/Shaun.jpg" alt="">                        
                                </div>                       
                            </div>
                            <div class="name">
                                <h3>Shaun Taylor</h3>
                            </div>                    
                            <div class="job">
                                <h3>Freelancer</h3>
                            </div>
                            <p>Neelesh and his team is great to work with and a very knowledgeable professional. Their expertise in Laravel, PHP and WP React are second to none. I've trusted him on various projects and wouldn't hesitate to recommend him.</p>
                        </li>
                        <!-- End Item testimonial-->

                        <!-- Item testimonial-->
                        <li>
                            <div class="head-testimonials">
                                <div class="image-testimonials">
                                    <img src="<?php echo base_url();?>/assets/images/client/Shiv.jpg" alt="">                        
                                </div>                       
                            </div>
                            <div class="name">
                                <h3>Shiv D Gadekar</h3>
                            </div>                    
                            <div class="job">
                                <h3>Owner of Farehawker</h3>
                            </div>
                            <p>Working with the team at Manifest Infotech was a pleasure to work. They listened to our ideas and turned them into a beautiful, functional website that exceeded our expectations.</p>
                        </li>
                        <!-- End Item testimonial-->

                        <!-- Item testimonial-->
                        <li>
                            <div class="head-testimonials">
                                <div class="image-testimonials">
                                    <img src="<?php echo base_url();?>/assets/images/client/Faraz khan.jpg" alt="">                        
                                </div>                       
                            </div>
                            <div class="name">
                                <h3>Faraz</h3>
                            </div>                    
                            <div class="job">
                                <h3>Manager at AlNapedh Technologies</h3>
                            </div>
                            <p>Great team to work with, really attentive and react to request immediately. Excellent work and I am really pleased with the results. Thanks Mianfest Infotech Team.</p>
                        </li>
                        <!-- End Item testimonial-->

                        <!-- Item testimonial-->
                        <li>
                            <div class="head-testimonials">
                                <div class="image-testimonials">
                                    <img src="<?php echo base_url();?>/assets/images/client/Irfan Khan.jpg" alt="">                        
                                </div>                       
                            </div>
                            <div class="name">
                                <h3>Irfan Khan</h3>
                            </div>                    
                            <div class="job">
                                <h3>Director at Infobinds</h3>
                            </div>
                            <p>We are very pleased working with Manifest Infotech and the way they conducts their business. It has been a great experience working with them. Highly recommended.</p>
                        </li>
                        <!-- End Item testimonial-->

                        <!-- Item testimonial-->
                        <li>
                            <div class="head-testimonials">
                                <div class="image-testimonials">
                                    <img src="<?php echo base_url();?>/assets/images/client/Sapna Talreja.jpg" alt="">                        
                                </div>                       
                            </div>
                            <div class="name">
                                <h3>Sapna Talreja</h3>
                            </div>                    
                            <div class="job">
                                <h3>Founder HappleyFit</h3>
                            </div>
                            <p>It was a pleasure working with the Manifest team, they are very professional. Best thing is they are always striving for the best and coming up with suggestions, and are very keen on learning new technologies, what I like most about them is their never say die approach. Would highly recommend them.</p>
                        </li>
                        <!-- End Item testimonial-->

                    </ul> 
                    <!-- End testimonials Carousel-->
                </section>  
                <!-- End testimonials--> 
            </section>   
            <!-- End content info - Testimonials Section--> 
          
            <!-- footer-->
            <footer class="">
                <div class="container">
                    <div class="row">
                        
                        <!-- Recent Links -->
                        <div class="col-md-2">
                            <h3>TECHNOLOGIES</h3>
                            <ul>
                                <li><i class="fa fa-check"></i><a href="#">Work</a></li>
                                <li><i class="fa fa-check"></i><a href="#">About Us</a></li>
                                <li><i class="fa fa-check"></i><a href="#">Services</a></li>
                                <li><i class="fa fa-check"></i><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                        <!-- End Recent Links-->

                        <!-- Recent Links -->
                        <div class="col-md-2">
                            <h3>RECENT LINKS</h3>
                            <ul>
                                <li><i class="fa fa-check"></i><a href="#">Work</a></li>
                                <li><i class="fa fa-check"></i><a href="#">About Us</a></li>
                                <li><i class="fa fa-check"></i><a href="#">Services</a></li>
                                <li><i class="fa fa-check"></i><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                        <!-- End Recent Links-->

                        <!-- Recent links-->
                        <div class="col-md-2">
                            <h3>NEW BLOGS</h3>
                            <div class="twitts"></div>                        
                        </div>
                        <!-- End Recent links-->

                        <!-- Contact Us-->
                        <div class="col-md-3">
                           <h3>CONTACT US</h3>
                           <ul class="contact_footer">
                                <li>
                                    <i class="fa fa-envelope"></i> <a href="mailto:info@manifestinfotech.com">info@manifestinfotech.com</a>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:info@manifestinfotech.com">nchouksey@manifestinfotech.com</a>
                                </li>
                                <li>
                                    <i class="fa fa-headphones"></i> <a href="#">+91 731 3582993, <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp+91 7771983222</a>
                                 </li>
                                <li class="location">
                                    <i class="fa fa-home"></i> <a href="#"> B-319, Tulsi Nagar, Indore<br></a>
                                </li>                                   
                            </ul>
                        </div>
                        <!-- Contact Us-->

                        <!-- Social Section-->
                        <div class="col-md-2">
                            <h3>FOLLOW US</h3>
                            <ul class="social">
                                <li class="linkedin"><a href="https://in.linkedin.com/company/manifest-infotech" target="_blank" Title="Linkedin"><span><i class="fa fa-linkedin"></i></span>Linkedin</a></li>
                                <li class="twitter"><a href="https://twitter.com/Manifest_info" target="_blank" Title="Twitter"><span><i class="fa fa-twitter"></i></span>Twitter</a></li>
                                <li class="instagram"><a href="https://www.instagram.com/manifestinfotech/" target="_blank" Title="Instagram"><span><i class="fa fa-instagram"></i></span>Instagram</a></li>
                                <li class="facebook"><a href="https://www.facebook.com/manifestinfotech" target="_blank" Title="Facebook"><span><i class="fa fa-facebook"></i></span>Facebook</a></li>
                                <li class="pinterest"><a href="https://www.pinterest.com/archananchoukse/" target="_blank" Title="Pinterest"><span><i class="fa fa-pinterest"></i></span>Pinterest</a></li>
                            </ul>
                        </div>
                        <!-- End Social Section-->

                    </div>
                </div>
            </footer>      
            <!-- End footer-->

            <!-- footer-->
            <footer class="coopring">
                <p>&copy; 2012 Manifest Infotech Pvt. Ltd. | All rights reserved.</p>
            </footer>      
            <!-- End footer-->
        </div>
        <!-- End layout-->
   
        <!-- ======================= JQuery libs =========================== -->
        <!-- jQuery local-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.js"></script>
        <!--Nav-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/nav/tinynav.js"></script> 
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/nav/superfish.js"></script> 
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/nav/hoverIntent.js"></script>  
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/nav/jquery.sticky.js"></script>                                               
        <!--Totop-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/totop/jquery.ui.totop.js" ></script>  
        <!--Slide Revolution-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/rs-plugin/js/jquery.themepunch.tools.min.js" ></script>      
        <script type='text/javascript' src='<?php echo base_url();?>/assets/js/rs-plugin/js/jquery.themepunch.revolution.min.js'></script>  
        <!--owl-carousel-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/carousel/owl.carousel.js"></script>    
        <!--Ligbox--> 
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/fancybox/jquery.fancybox.pack.js"></script>  
        <!--Gallery Grid--> 
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/gallery/modernizr.custom.26633.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/gallery/jquery.gridrotator.js"></script>     
        <!--Minislider Team-->         
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/team/modernizr.custom.63321.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/team/jquery.catslider.js"></script> 
        <!--Filters-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/filters/jquery.isotope.js" ></script>   
        <!--Theme Options-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/theme-options/theme-options.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/theme-options/jquery.cookies.js"></script> 
        <!-- Twitter Feed-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/twitter/jquery.tweet.js"></script>   
        <!-- WOW-master-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/animations/wow.min.js"></script> 
        <!-- Parallax-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/parallax/jquery.inview.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/parallax/nbw-parallax.js"></script>                           
        <!-- Bootstrap.js-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/bootstrap/bootstrap.js"></script>
        <!--fUNCTIONS-->
        <script type="text/javascript" src="<?php echo base_url();?>/assets/js/main.js"></script>
        <!-- ======================= End JQuery libs =========================== -->
        
        <!--Slider Function-->
        <script type="text/javascript">
            jQuery(document).ready(function() {
               jQuery('.tp-banner').revolution(
                {
                    delay:15000,
                    startwidth:1170,
                    startheight:500,
                    hideThumbs:10,
                    fullWidth:"on",
                    fullScreen:"on",
                    fullScreenOffsetContainer: ""
                });
            });
        </script>
        <!--End Slider Function-->
  </body>
</html>