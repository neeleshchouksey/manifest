<section class="page-cover About-cover-img">
  <div class="container-fluid">
    <div class="container">
      <div class="page-heading">
        <h3>EXPERTISE</h3>
        <h4>Our work define our Competence</h4>
        <p>We are having years of Industry experience in dealing various projects and providing exceptional & cost effective solutions</p>
      </div>
    </div>
  </div>
</section>


<section class="page-section coo_otr" >
  <div  class="container-fluid">
    <div class="container">
      <div class="page-heading"> </div>
      <div class="spacer-mini"></div>
      <div class="container">
        <div class=" row-fluid">
          <div class="span12">
            <div class="border pull-right thumb-right"> <a href="JavaScript:Void(0)" class="shadow"> 
              <!--<img  width="250" src="img/home-about/about-us.jpg" title="About Us">--> 
              </a> </div>
            <h3>Experties</h3>
            <br />
            <p class="process_prg justify"> We are offers our expertise technologies in our services and solutions with multiple technology platforms and can be extended to provide interface to various mobile devices, you would need the expertise of someone like us.</p> 
          <br />
			   </div>
  			<div>
          <h4>PHP </h4>
           <br />
              <p class="process_prg justify">We are PHP Development company expertise in creating web applications and website and also we create Frameworks and CMS as per the project requirement. With use of custom PHP development, we create website which is fast, manageable and user friendly. Our CMS techniques helps you to manage your website with very less effort. We are working on the following technologies :</p> 
            <br />
          <ul class="bullet_process check_right check_ic span12 pull-left">
            <li><i class="fa fa-circle-o"></i>CodeIgniter </li>
            <li><i class="fa fa-circle-o"></i>CakePHP development</li>
            <li><i class="fa fa-circle-o"></i>YII</li>
            <li><i class="fa fa-circle-o"></i>Zend</li>
            <li><i class="fa fa-circle-o"></i>Drupal</li>
            <li><i class="fa fa-circle-o"></i>Wordpress </li>
            <li><i class="fa fa-circle-o"></i>Joomla </li>
            <li><i class="fa fa-circle-o"></i>Education</li>
            <li><i class="fa fa-circle-o"></i>Ruby on Rails </li>
          </ul>
  			</div>

        <div>
          <h4>Python </h4>
           <br />
              <p class="process_prg justify">Python programming language is most useful web development source for the clients. We are providing  years of experience team of python development  for the applications development, upgrade applications and for designing python applications. </p> 
            <br />
        </div>

        <div>
          <h4>.NET </h4>
           <br />
              <p class="process_prg justify">We offers various .NET languages like Asp.net, VB.net, C#, MVC Architecture - 3.0 & 4.0, Web Forms, SQL Server - 2008, 2010, Jquery, Node.js, Handlebar, Angular js etc. We also provide Microsoft technologies like Azure Server, Amazon Server, Cloud Server. We provide our clients Memory Management, Debugging Support, Security, Version Control, Mixed Language Interaction. </p> 
            <br />
       </div>

       <div>
        <h4>Android </h4>
         <br />
            <p class="process_prg justify">We are Software development company providing Android application development solutions with the standard quality. We are having expertise team for Android development as per the requirement of the clients and also provide best in class services during the development and technical support provided after the completion of projects. We customized Android apps development, apps testing and probability, Android support and maintenance for the projects. </p> 
          <br />
       </div>

        <div>
          <h4>iOS </h4>
           <br />
              <p class="process_prg justify">Our team having years of experience in development and designing of iPhone/ iPad application. Our team help the client in conceptualizing and visualising the idea of project, also customising the idea of businesses. We are providing user friendly applications that increase the usability and improve the accessibility of clients business. iPhone/iPad application can work in many domain, we provide services in the domain they want to build their business. </p> 
            <br />
        </div>

        <div>
          <h4>Design </h4>
           <br />
              <p class="process_prg justify">We are gaining years of experience in completed successful projects in designing the website. We raising the bar of standard quality of design, we always follow the rule to cross our own branch marking in designing. We are providing following services for our clients along with quality and maintaining the standard.</p> 
            <br />
          <ul class="bullet_process check_right check_ic span12 pull-left">
            <li><i class="fa fa-circle-o"></i>Logo Design </li>
            <li><i class="fa fa-circle-o"></i>Web Design</li>
            <li><i class="fa fa-circle-o"></i>Mobile app design</li>
            <li><i class="fa fa-circle-o"></i>Template design</li>
          </ul>
        </div>

         <div>
          <h4>Front End Development </h4>
           <br />
              <p class="process_prg justify">Our development team makes an effort to create amazing and user friendly front end of website which user can easily interact with. We are providing experience offshore user interface design and web development for the clients to meet the internal and external requirement of the businesses. We are working in the following technologies to complete the requirement of clients. </p> 
              <ul class="bullet_process check_right check_ic span12 pull-left">
                <li><i class="fa fa-circle-o"></i>HTML5 </li>
                <li><i class="fa fa-circle-o"></i>CSS3</li>
                <li><i class="fa fa-circle-o"></i>Bootstrap</li>
                <li><i class="fa fa-circle-o"></i>JQuery</li>
                <li><i class="fa fa-circle-o"></i>Angularjs</li>
                <li><i class="fa fa-circle-o"></i>node.js Ajax</li>
              </ul>
            <br />
        </div>

        <div>
          <h4>Database </h4>
           <br />
              <p class="process_prg justify">We are providing Database services to clients for better performance, administration, and security of their database. We are offers the services like Data management, backup, performance analysis, logging etc. This database services helps the clients to increased security, better flexibility, effective data sharing, enables backup and recovery etc. </p> 
            <br />
       </div>
          </div>
        </div>
      </div>
    </div>
 
</section>