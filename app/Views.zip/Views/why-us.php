<section class="page-cover About-cover-img">
  <div class="container-fluid">
    <div class="container">
      <div class="page-heading">
        <h3>WHY US</h3>
        <h4>Our PASSION shows it</h4>
        <p>Our motto is to provides Quality Services to our clients & We are having assurance of their satisfaction</p>
      </div>
    </div>
  </div>
</section>
<section class="page-section coo_otr" >
  <div  class="container-fluid">
    <div class="container">
      <div class="page-heading"> </div>
      <div class="spacer-mini"></div>
      <div class="container">
        <div class=" row-fluid">
          <div class="span12">
            <div class="border pull-right thumb-right"> <a href="#" class="shadow"> 
              <!--<img  width="250" src="assets/images/home-about/about-us.jpg" title="About Us">-----> 
              </a> </div>
            <h3>Why Us</h3>
            <br />
            <p class="justify process_prg">In India, we are different from other development companies because:</p>
            <p class="justify process_prg"><b>We are focused on core Web development- </b>We have successfully built 
              core intellectual property for several customers in their journey from pre-funded startups to a 
              profitable acquisition. We have the deep technological expertise,
              proven track record and unique methodology to build products successfully. </p>
			  <br />
            <p class="justify process_prg"><b>We don't believe in ISO & CMM certifications- </b>When it comes to innovation, no amount of 
              process standardization can substitute for smartness. We hire only the best. We restrict hiring to experienced 
              graduates of the top 20 engineering schools in India. Most of our employees come to us from the top Indian IT 
              companies as well as large multinationals having 
              their captive centers here.</p>
			  <br />
            <p class="justify process_prg"><b>We don't expect you to spend half your time writing long, detailed specs	-</b> We take pains to understand your business, not just your technology needs. As a result, our developers a
              re able to understand your needs through brief communication. Typically, requirements come to us via 
              simple "we need this feature" emails. 
              We are equally at ease following any requirement and project management tool that you may use. </p>
			  <br />
            <p class="justify process_prg">In the long run, we believe that you are best off owning your offshore 
              team.</> Success is most dependent on teams at both shores working towards the same end, and this 
              is best done by owning your subsidiary. However, starting off on your own in an unknown business 
              environment has its own risks. Also, you need a minimum threshold size for a subsidiary to make 
              economic sense. With our Build-Operate-Transfer business model, we mitigate the risk of unknown
              business environment, help you learn best practices to ensure success till such time that you are 
              ready to go on your own. </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>